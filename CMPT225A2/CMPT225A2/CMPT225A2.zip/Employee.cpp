#include "Employee.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string Employee::getName() {
	return nameVar;
}
int Employee::getEmployeeID() {
	return employeeIDVAR;
}
string Employee::toString() {
	string getNameString = getName();
	return getNameString + " " + to_string(getEmployeeID());
}