#ifndef ARRAYUTILS_H
#define ARRAYUTILS_H
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
template<typename T>
class ArrayUtils {
public:
static void reverse(T* array, int size);
};

#endif