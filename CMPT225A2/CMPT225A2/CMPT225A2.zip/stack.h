#ifndef STACK_H
#define STACK_H
#include <string>
#include <iostream>
using namespace std;
template <typename T>
class Stack {
private:
	int capacityNumber = 0;
	int top = -1;
	T* stackPTR = stack;
	T* (*stack) = new T[capacityNumber]; //pointer of type T to an array of size capacityNumber
public:
	T& pop();
	void push(T&);
	bool empty();
	int size();
	int capacity();
	T getArray() {
		return *stack;
	}
	//Constructor
	Stack();
	Stack(int capacity);
	//Destructor
	~Stack() {
		cout << "Stack has been destroyed\n";
	}
};


class EmptyStackException {
private:
	string errorMsg;
public:
	EmptyStackException(const string& err) {
		errorMsg = err;
	}
	string getMessage() const {
		return errorMsg;
	}

};


#endif