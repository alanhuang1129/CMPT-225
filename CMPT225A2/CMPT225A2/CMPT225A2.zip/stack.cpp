#include "stack.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
template <typename T>

Stack<T>::Stack() : Stack(0) {}
template <typename T>
Stack<T>::Stack(int capacity) {
	capacityNumber = capacity;
}
template <typename T>
T& Stack<T>::pop() throw(EmptyStackException){
	try {
		if (top <= -1) {//Stack already empty
			throw EmptyStackException("Stack is empty");
		}
	}
	catch (EmptyStackException ese) {
		cout << ese.getMessage() << endl;
	}
	T temp = *stackPTR;
	top--;//Move top of stack is taken out and stackPTR points the the object below
	if (top == -1) { //Empty stack
		stackPTR = NULL;
	}
	else { //Not empty stack
		stackPTR = **(stack + top - 1);
	}
		return temp;
}
template <typename T>
void Stack<T>::push(T&) {
	if (top + 1 == capacity) {
		T (*newStack)[stack.capacity() * 2]; //new pointer to an array of double size
		capacityNumber = stack.capacity() * 2; //setting the new capacity
		for (int i = 0; i <= top; i++) {
			**(newStack + i) = **(stack + i); //read - write process
		}
		top++;
		**(newStack + top) = T; //dereferences to find the element within the array at (top)th element
		stackPTR = *(stackPTR + 1); //point to next element
		stack = newStack; //repoints stack to new stack
	}
	else {
		top++;
		**(stack + top) = T;
		stackPTR = **(stack + top);
	}
};
template <typename T>
bool Stack<T>::empty() {
	if (top == -1) {
		return true;
	}
	else
		return false;
};
template <typename T>
int Stack<T>::size() {
	return (top + 1);
};
template <typename T>
int Stack<T>::capacity() {
	return capacity;
};