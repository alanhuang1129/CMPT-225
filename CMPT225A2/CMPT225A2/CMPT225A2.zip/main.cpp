#include "stack.h"
#include "arrayutils.h"
#include "Employee.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;
//Test Function Declarations
void testStackUnderflow();
void testStackGrowth();
void testReverseIntegers();
void testReverseStrings();
void testReverseEmployees();

int main() {
	testStackUnderflow();
	cout << endl << endl;
	testStackGrowth();
	cout << endl << endl;
	testReverseIntegers();
	cout << endl << endl;
	testReverseStrings();
	cout << endl << endl;
	testReverseEmployees();
	cout << endl << endl;
	return 0;
}

//Test Function Definitions
void testStackUnderflow() {
	try {
		int four = 4;
		Stack<int> intStack(5);
		intStack.push(four);
		intStack.pop();
		intStack.pop();
		cout << "did not catch exception";
	}
	catch(EmptyStackException testESE){
		cout << "caught EmptyStackException";
	}
}


void testStackGrowth() {
	Stack<int> testStack(4);
	int intArray[10];
	for (int i = 0; i <= 9; i++) {
		intArray[i] = i;
		if (i == 4 || i == 9) {
			cout << testStack.capacity();
		}
		if (i < 9) {
			testStack.push(intArray[i]);
			cout << "---Pushed integer " << i << " onto the stack---\n";
		}
	}
	for (int j = 0; j < 9; j++) {
		cout << testStack.pop() << " was popped out of the Test Stack\n";
	}
}

void testReverseIntegers() {
	int integerArray[12];
	//loop for assigning values
	for (int i = 0; i < 12; i++) {
		integerArray[i] = i;
	}
	//loop for printing values
	for (int j = 0; j < 12; j++) {
		cout << integerArray[j] << " ";
	}
	cout << endl;
	ArrayUtils<int>::reverse(integerArray, 12);
	//loop for printing values again
	for (int k = 0; k < 12; k++) {
		cout << integerArray[k] << " ";
	}
}
void testReverseStrings() {
	string arrayOfStrings[12] = { "1", "2" , "3" , "4" , "5" , "6" , "7" , "8" , "9", "10", "11" ,"12" };
	for (int i = 0; i < 12; i++) {
		cout << arrayOfStrings[i] << "   ";
	}
	cout << endl;
	ArrayUtils<string>::reverse(arrayOfStrings, 12);
	for (int j = 0; j < 12; j++) {
		cout << arrayOfStrings[j] << "   ";
	}
	cout << endl;
}
void testReverseEmployees() {
	Employee em1("em1", 1);
	Employee em2("em2", 2);
	Employee em3("em3", 3);
	Employee em4("em4", 4);
	Employee em5("em5", 5);
	Employee em6("em6", 6);
	Employee em7("em7", 7);
	Employee em8("em8", 8);
	Employee em9("em9", 9);
	Employee em10("em10", 10);
	Employee em11("em11", 11);
	Employee em12("em12", 12);
	Employee employeeArray[12] = { em1, em2, em3, em4, em5, em6, em7, em8, em9, em10, em11, em12 };
	for (int i = 0; i < 12; i++) {
		cout << employeeArray[i].toString() << "    ";
	}
	cout << endl;
	ArrayUtils<Employee>::reverse(employeeArray, 12);
	for (int j = 0; j < 12; j++) {
		cout << employeeArray[j].toString() << "    ";
	}
	
}



