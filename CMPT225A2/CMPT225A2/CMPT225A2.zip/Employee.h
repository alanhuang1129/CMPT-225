#ifndef EMPLOYEES_H
#define EMPLOYEES_H
#include <iostream>
#include <iomanip>
#include <string>
using namespace std; //I'm getting a compile error at this line??? Visual Studio is bad for my sanity

class Employee {
private:
	string nameVar;
	int employeeIDVAR;
public:
	Employee() : Employee("", 0) {};
	Employee(string name, int employeeID) {
		nameVar = name;
		employeeIDVAR = employeeID;
	};
	string getName();
	int getEmployeeID();
	string toString();
}

#endif