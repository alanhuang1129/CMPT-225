#include "arraylist.h"
#include <iostream>
#include <string>
using namespace std;

void testArrayListUnderflow();
void testIntegerIterator();
void testStringIterator();


int main() {
	//ArrayListUnderflow
	testArrayListUnderflow();
	cout << endl;
	//IntegerIterator
	testIntegerIterator();
	cout << endl;
	//StringIterator
	testStringIterator();
	cout << endl;
	return 0;
}


void testArrayListUnderflow() {
	int arrayList[4] = { 1,2,3,4 };
	ArrayList<int> intList; //Defaulted to capacity of 4

	try {
		intList.insertFront(arrayList[0]);
		intList.removeFront();
		intList.removeFront();
		cout << "Did not catch exception\n";
	}
	catch (EmptyListException ele) {
		cout << "caught EmptyListException\n"; //The assignment says to print EmptyStackException but it's an arraylist
	}

	try {
		intList.insertBack(arrayList[0]);
		intList.removeBack();
		intList.removeBack();
		cout << "Did not catch exception\n";
	}
	catch (EmptyListException ele) {
		cout << "caught EmptyListException\n";
	}

	try {
		intList.insert(intList.begin(), arrayList[0]);
		intList.remove(intList.begin());
		intList.remove(intList.begin());
		cout << "Did not catch exception\n";
	}
	catch (EmptyListException ele) {
		cout << "caught EmptyListException\n";
	}
}
void testIntegerIterator() {
	int arrayList[6] = { 1,2,3,4,5,6 };
	ArrayList<int> intList; //Defaulted to capacity of 4

	//Insert 6 integers
	for (int i = 0; i < 6; i++)
		intList.insertBack(arrayList[i]);

	//Print List
	for (ArrayList<int>::Iterator iter = intList.begin(); iter != intList.end(); iter++) {
		cout << *iter << " ";
	}
	cout << endl;

	//Remove 3
	for (int i = 0; i < 3; i++)
		intList.removeFront();

	//Insert 3
	for (int j = 0; j < 3; j++)
		intList.insertBack(arrayList[j]);

	//Print List
	for (ArrayList<int>::Iterator iter = intList.begin(); iter != intList.end(); iter++) {
		cout << *iter << " ";
	}
	cout << endl;
}

void testStringIterator() {
	string arrayList[6] = { "a","b","c","d","e","f" };
	ArrayList<string> stringList; //Capacity of 4

	//Insert 6 strings
	for (int i = 0; i < 6; i++)
		stringList.insertBack(arrayList[i]);

	//Print List
	for (ArrayList<string>::Iterator iter = stringList.begin(); iter != stringList.end(); iter++) {
		cout << *iter << " ";
	}
	cout << endl;

	//Remove 3
	for (int i = 0; i < 3; i++)
		stringList.removeFront();

	//Insert 3
	for (int j = 0; j < 3; j++)
		stringList.insertBack(arrayList[j]);

	//Print List
	for (ArrayList<string>::Iterator iter = stringList.begin(); iter != stringList.end(); iter++) {
		cout << *iter << " ";
	}
	cout << endl;
}
